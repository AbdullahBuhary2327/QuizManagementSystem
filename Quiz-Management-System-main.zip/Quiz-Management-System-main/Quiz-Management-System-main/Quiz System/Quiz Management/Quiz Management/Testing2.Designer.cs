﻿namespace Quiz_Management
{
    partial class Testing2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Testing2));
            this.TimeBar = new System.Windows.Forms.ProgressBar();
            this.Q10O4 = new System.Windows.Forms.RadioButton();
            this.logoutPop = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.QTime = new System.Windows.Forms.DateTimePicker();
            this.DateP = new System.Windows.Forms.DateTimePicker();
            this.TimeLbl = new System.Windows.Forms.Label();
            this.Q10 = new System.Windows.Forms.GroupBox();
            this.Q10O3 = new System.Windows.Forms.RadioButton();
            this.Q10O2 = new System.Windows.Forms.RadioButton();
            this.Q10O1 = new System.Windows.Forms.RadioButton();
            this.Q9 = new System.Windows.Forms.GroupBox();
            this.Q9O4 = new System.Windows.Forms.RadioButton();
            this.Q9O3 = new System.Windows.Forms.RadioButton();
            this.Q9O2 = new System.Windows.Forms.RadioButton();
            this.Q9O1 = new System.Windows.Forms.RadioButton();
            this.Q8 = new System.Windows.Forms.GroupBox();
            this.Q8O4 = new System.Windows.Forms.RadioButton();
            this.Q8O3 = new System.Windows.Forms.RadioButton();
            this.Q8O2 = new System.Windows.Forms.RadioButton();
            this.Q8O1 = new System.Windows.Forms.RadioButton();
            this.SubLbl = new System.Windows.Forms.Label();
            this.Q7 = new System.Windows.Forms.GroupBox();
            this.Q7O4 = new System.Windows.Forms.RadioButton();
            this.Q7O3 = new System.Windows.Forms.RadioButton();
            this.Q7O2 = new System.Windows.Forms.RadioButton();
            this.Q7O1 = new System.Windows.Forms.RadioButton();
            this.Q4 = new System.Windows.Forms.GroupBox();
            this.Q4O4 = new System.Windows.Forms.RadioButton();
            this.Q4O3 = new System.Windows.Forms.RadioButton();
            this.Q4O2 = new System.Windows.Forms.RadioButton();
            this.Q4O1 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.CNameLbl = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Q2O4 = new System.Windows.Forms.RadioButton();
            this.Q2 = new System.Windows.Forms.GroupBox();
            this.Q2O3 = new System.Windows.Forms.RadioButton();
            this.Q2O2 = new System.Windows.Forms.RadioButton();
            this.Q2O1 = new System.Windows.Forms.RadioButton();
            this.Q3O4 = new System.Windows.Forms.RadioButton();
            this.Q3O3 = new System.Windows.Forms.RadioButton();
            this.Q3O2 = new System.Windows.Forms.RadioButton();
            this.Q3O1 = new System.Windows.Forms.RadioButton();
            this.Q5O4 = new System.Windows.Forms.RadioButton();
            this.Q5O3 = new System.Windows.Forms.RadioButton();
            this.Q3 = new System.Windows.Forms.GroupBox();
            this.Q5O2 = new System.Windows.Forms.RadioButton();
            this.Q5 = new System.Windows.Forms.GroupBox();
            this.Q5O1 = new System.Windows.Forms.RadioButton();
            this.Q6O4 = new System.Windows.Forms.RadioButton();
            this.Q6O3 = new System.Windows.Forms.RadioButton();
            this.Q6O2 = new System.Windows.Forms.RadioButton();
            this.Q6O1 = new System.Windows.Forms.RadioButton();
            this.Q6 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Q1 = new System.Windows.Forms.GroupBox();
            this.Q1O4 = new System.Windows.Forms.RadioButton();
            this.Q1O3 = new System.Windows.Forms.RadioButton();
            this.Q1O2 = new System.Windows.Forms.RadioButton();
            this.Q1O1 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.SubmitBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button3 = new System.Windows.Forms.Button();
            this.exitPop = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.logoutPop.SuspendLayout();
            this.panel3.SuspendLayout();
            this.Q10.SuspendLayout();
            this.Q9.SuspendLayout();
            this.Q8.SuspendLayout();
            this.Q7.SuspendLayout();
            this.Q4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.Q2.SuspendLayout();
            this.Q3.SuspendLayout();
            this.Q5.SuspendLayout();
            this.Q6.SuspendLayout();
            this.panel1.SuspendLayout();
            this.Q1.SuspendLayout();
            this.exitPop.SuspendLayout();
            this.SuspendLayout();
            // 
            // TimeBar
            // 
            this.TimeBar.BackColor = System.Drawing.Color.DodgerBlue;
            this.TimeBar.Location = new System.Drawing.Point(959, 650);
            this.TimeBar.MarqueeAnimationSpeed = 1;
            this.TimeBar.Maximum = 1100;
            this.TimeBar.Name = "TimeBar";
            this.TimeBar.Size = new System.Drawing.Size(189, 15);
            this.TimeBar.Step = 1;
            this.TimeBar.TabIndex = 35;
            // 
            // Q10O4
            // 
            this.Q10O4.AutoSize = true;
            this.Q10O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q10O4.Location = new System.Drawing.Point(17, 121);
            this.Q10O4.Name = "Q10O4";
            this.Q10O4.Size = new System.Drawing.Size(92, 25);
            this.Q10O4.TabIndex = 27;
            this.Q10O4.TabStop = true;
            this.Q10O4.Text = "Option4";
            this.Q10O4.UseVisualStyleBackColor = true;
            // 
            // logoutPop
            // 
            this.logoutPop.BackColor = System.Drawing.Color.Silver;
            this.logoutPop.Controls.Add(this.label2);
            this.logoutPop.Controls.Add(this.button1);
            this.logoutPop.Controls.Add(this.button2);
            this.logoutPop.Location = new System.Drawing.Point(428, 248);
            this.logoutPop.Name = "logoutPop";
            this.logoutPop.Size = new System.Drawing.Size(455, 100);
            this.logoutPop.TabIndex = 31;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(51, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(317, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Are You Sure You want to Logout?";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(247, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "No";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(155, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 0;
            this.button2.Text = "Yes";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.button6);
            this.panel3.Controls.Add(this.button7);
            this.panel3.Location = new System.Drawing.Point(253, 237);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(455, 100);
            this.panel3.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(5, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(431, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Are You Sure You want to close the Programm?";
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(247, 65);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "No";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(155, 65);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 0;
            this.button7.Text = "Yes";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // QTime
            // 
            this.QTime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.QTime.Location = new System.Drawing.Point(973, 37);
            this.QTime.Name = "QTime";
            this.QTime.Size = new System.Drawing.Size(200, 23);
            this.QTime.TabIndex = 37;
            // 
            // DateP
            // 
            this.DateP.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.DateP.Location = new System.Drawing.Point(973, 5);
            this.DateP.Name = "DateP";
            this.DateP.Size = new System.Drawing.Size(200, 23);
            this.DateP.TabIndex = 36;
            // 
            // TimeLbl
            // 
            this.TimeLbl.AutoSize = true;
            this.TimeLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.TimeLbl.ForeColor = System.Drawing.Color.White;
            this.TimeLbl.Location = new System.Drawing.Point(1017, 618);
            this.TimeLbl.Name = "TimeLbl";
            this.TimeLbl.Size = new System.Drawing.Size(73, 29);
            this.TimeLbl.TabIndex = 29;
            this.TimeLbl.Text = "Time";
            // 
            // Q10
            // 
            this.Q10.Controls.Add(this.Q10O4);
            this.Q10.Controls.Add(this.Q10O3);
            this.Q10.Controls.Add(this.Q10O2);
            this.Q10.Controls.Add(this.Q10O1);
            this.Q10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q10.Location = new System.Drawing.Point(608, 430);
            this.Q10.Name = "Q10";
            this.Q10.Size = new System.Drawing.Size(275, 158);
            this.Q10.TabIndex = 33;
            this.Q10.TabStop = false;
            this.Q10.Text = "Question 1";
            // 
            // Q10O3
            // 
            this.Q10O3.AutoSize = true;
            this.Q10O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q10O3.Location = new System.Drawing.Point(17, 92);
            this.Q10O3.Name = "Q10O3";
            this.Q10O3.Size = new System.Drawing.Size(92, 25);
            this.Q10O3.TabIndex = 26;
            this.Q10O3.TabStop = true;
            this.Q10O3.Text = "Option3";
            this.Q10O3.UseVisualStyleBackColor = true;
            // 
            // Q10O2
            // 
            this.Q10O2.AutoSize = true;
            this.Q10O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q10O2.Location = new System.Drawing.Point(17, 64);
            this.Q10O2.Name = "Q10O2";
            this.Q10O2.Size = new System.Drawing.Size(92, 25);
            this.Q10O2.TabIndex = 25;
            this.Q10O2.TabStop = true;
            this.Q10O2.Text = "Option2";
            this.Q10O2.UseVisualStyleBackColor = true;
            // 
            // Q10O1
            // 
            this.Q10O1.AutoSize = true;
            this.Q10O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q10O1.Location = new System.Drawing.Point(17, 35);
            this.Q10O1.Name = "Q10O1";
            this.Q10O1.Size = new System.Drawing.Size(92, 25);
            this.Q10O1.TabIndex = 24;
            this.Q10O1.TabStop = true;
            this.Q10O1.Text = "Option1";
            this.Q10O1.UseVisualStyleBackColor = true;
            // 
            // Q9
            // 
            this.Q9.Controls.Add(this.Q9O4);
            this.Q9.Controls.Add(this.Q9O3);
            this.Q9.Controls.Add(this.Q9O2);
            this.Q9.Controls.Add(this.Q9O1);
            this.Q9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q9.Location = new System.Drawing.Point(313, 430);
            this.Q9.Name = "Q9";
            this.Q9.Size = new System.Drawing.Size(275, 158);
            this.Q9.TabIndex = 34;
            this.Q9.TabStop = false;
            this.Q9.Text = "Question 1";
            // 
            // Q9O4
            // 
            this.Q9O4.AutoSize = true;
            this.Q9O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q9O4.Location = new System.Drawing.Point(17, 121);
            this.Q9O4.Name = "Q9O4";
            this.Q9O4.Size = new System.Drawing.Size(92, 25);
            this.Q9O4.TabIndex = 27;
            this.Q9O4.TabStop = true;
            this.Q9O4.Text = "Option4";
            this.Q9O4.UseVisualStyleBackColor = true;
            // 
            // Q9O3
            // 
            this.Q9O3.AutoSize = true;
            this.Q9O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q9O3.Location = new System.Drawing.Point(17, 92);
            this.Q9O3.Name = "Q9O3";
            this.Q9O3.Size = new System.Drawing.Size(92, 25);
            this.Q9O3.TabIndex = 26;
            this.Q9O3.TabStop = true;
            this.Q9O3.Text = "Option3";
            this.Q9O3.UseVisualStyleBackColor = true;
            // 
            // Q9O2
            // 
            this.Q9O2.AutoSize = true;
            this.Q9O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q9O2.Location = new System.Drawing.Point(17, 64);
            this.Q9O2.Name = "Q9O2";
            this.Q9O2.Size = new System.Drawing.Size(92, 25);
            this.Q9O2.TabIndex = 25;
            this.Q9O2.TabStop = true;
            this.Q9O2.Text = "Option2";
            this.Q9O2.UseVisualStyleBackColor = true;
            // 
            // Q9O1
            // 
            this.Q9O1.AutoSize = true;
            this.Q9O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q9O1.Location = new System.Drawing.Point(17, 35);
            this.Q9O1.Name = "Q9O1";
            this.Q9O1.Size = new System.Drawing.Size(92, 25);
            this.Q9O1.TabIndex = 24;
            this.Q9O1.TabStop = true;
            this.Q9O1.Text = "Option1";
            this.Q9O1.UseVisualStyleBackColor = true;
            // 
            // Q8
            // 
            this.Q8.Controls.Add(this.Q8O4);
            this.Q8.Controls.Add(this.Q8O3);
            this.Q8.Controls.Add(this.Q8O2);
            this.Q8.Controls.Add(this.Q8O1);
            this.Q8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q8.Location = new System.Drawing.Point(898, 248);
            this.Q8.Name = "Q8";
            this.Q8.Size = new System.Drawing.Size(275, 158);
            this.Q8.TabIndex = 29;
            this.Q8.TabStop = false;
            this.Q8.Text = "Question 1";
            // 
            // Q8O4
            // 
            this.Q8O4.AutoSize = true;
            this.Q8O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q8O4.Location = new System.Drawing.Point(17, 121);
            this.Q8O4.Name = "Q8O4";
            this.Q8O4.Size = new System.Drawing.Size(92, 25);
            this.Q8O4.TabIndex = 27;
            this.Q8O4.TabStop = true;
            this.Q8O4.Text = "Option4";
            this.Q8O4.UseVisualStyleBackColor = true;
            // 
            // Q8O3
            // 
            this.Q8O3.AutoSize = true;
            this.Q8O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q8O3.Location = new System.Drawing.Point(17, 92);
            this.Q8O3.Name = "Q8O3";
            this.Q8O3.Size = new System.Drawing.Size(92, 25);
            this.Q8O3.TabIndex = 26;
            this.Q8O3.TabStop = true;
            this.Q8O3.Text = "Option3";
            this.Q8O3.UseVisualStyleBackColor = true;
            // 
            // Q8O2
            // 
            this.Q8O2.AutoSize = true;
            this.Q8O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q8O2.Location = new System.Drawing.Point(17, 64);
            this.Q8O2.Name = "Q8O2";
            this.Q8O2.Size = new System.Drawing.Size(92, 25);
            this.Q8O2.TabIndex = 25;
            this.Q8O2.TabStop = true;
            this.Q8O2.Text = "Option2";
            this.Q8O2.UseVisualStyleBackColor = true;
            // 
            // Q8O1
            // 
            this.Q8O1.AutoSize = true;
            this.Q8O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q8O1.Location = new System.Drawing.Point(17, 35);
            this.Q8O1.Name = "Q8O1";
            this.Q8O1.Size = new System.Drawing.Size(92, 25);
            this.Q8O1.TabIndex = 24;
            this.Q8O1.TabStop = true;
            this.Q8O1.Text = "Option1";
            this.Q8O1.UseVisualStyleBackColor = true;
            // 
            // SubLbl
            // 
            this.SubLbl.AutoSize = true;
            this.SubLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SubLbl.ForeColor = System.Drawing.Color.White;
            this.SubLbl.Location = new System.Drawing.Point(73, 9);
            this.SubLbl.Name = "SubLbl";
            this.SubLbl.Size = new System.Drawing.Size(101, 29);
            this.SubLbl.TabIndex = 30;
            this.SubLbl.Text = "Subject";
            // 
            // Q7
            // 
            this.Q7.Controls.Add(this.Q7O4);
            this.Q7.Controls.Add(this.Q7O3);
            this.Q7.Controls.Add(this.Q7O2);
            this.Q7.Controls.Add(this.Q7O1);
            this.Q7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q7.Location = new System.Drawing.Point(608, 248);
            this.Q7.Name = "Q7";
            this.Q7.Size = new System.Drawing.Size(275, 158);
            this.Q7.TabIndex = 28;
            this.Q7.TabStop = false;
            this.Q7.Text = "Question 1";
            // 
            // Q7O4
            // 
            this.Q7O4.AutoSize = true;
            this.Q7O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q7O4.Location = new System.Drawing.Point(17, 121);
            this.Q7O4.Name = "Q7O4";
            this.Q7O4.Size = new System.Drawing.Size(92, 25);
            this.Q7O4.TabIndex = 27;
            this.Q7O4.TabStop = true;
            this.Q7O4.Text = "Option4";
            this.Q7O4.UseVisualStyleBackColor = true;
            // 
            // Q7O3
            // 
            this.Q7O3.AutoSize = true;
            this.Q7O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q7O3.Location = new System.Drawing.Point(17, 92);
            this.Q7O3.Name = "Q7O3";
            this.Q7O3.Size = new System.Drawing.Size(92, 25);
            this.Q7O3.TabIndex = 26;
            this.Q7O3.TabStop = true;
            this.Q7O3.Text = "Option3";
            this.Q7O3.UseVisualStyleBackColor = true;
            // 
            // Q7O2
            // 
            this.Q7O2.AutoSize = true;
            this.Q7O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q7O2.Location = new System.Drawing.Point(17, 64);
            this.Q7O2.Name = "Q7O2";
            this.Q7O2.Size = new System.Drawing.Size(92, 25);
            this.Q7O2.TabIndex = 25;
            this.Q7O2.TabStop = true;
            this.Q7O2.Text = "Option2";
            this.Q7O2.UseVisualStyleBackColor = true;
            // 
            // Q7O1
            // 
            this.Q7O1.AutoSize = true;
            this.Q7O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q7O1.Location = new System.Drawing.Point(17, 35);
            this.Q7O1.Name = "Q7O1";
            this.Q7O1.Size = new System.Drawing.Size(92, 25);
            this.Q7O1.TabIndex = 24;
            this.Q7O1.TabStop = true;
            this.Q7O1.Text = "Option1";
            this.Q7O1.UseVisualStyleBackColor = true;
            // 
            // Q4
            // 
            this.Q4.Controls.Add(this.Q4O4);
            this.Q4.Controls.Add(this.Q4O3);
            this.Q4.Controls.Add(this.Q4O2);
            this.Q4.Controls.Add(this.Q4O1);
            this.Q4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q4.Location = new System.Drawing.Point(898, 73);
            this.Q4.Name = "Q4";
            this.Q4.Size = new System.Drawing.Size(275, 158);
            this.Q4.TabIndex = 32;
            this.Q4.TabStop = false;
            this.Q4.Text = "Question 1";
            // 
            // Q4O4
            // 
            this.Q4O4.AutoSize = true;
            this.Q4O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q4O4.Location = new System.Drawing.Point(17, 121);
            this.Q4O4.Name = "Q4O4";
            this.Q4O4.Size = new System.Drawing.Size(92, 25);
            this.Q4O4.TabIndex = 27;
            this.Q4O4.TabStop = true;
            this.Q4O4.Text = "Option4";
            this.Q4O4.UseVisualStyleBackColor = true;
            // 
            // Q4O3
            // 
            this.Q4O3.AutoSize = true;
            this.Q4O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q4O3.Location = new System.Drawing.Point(17, 92);
            this.Q4O3.Name = "Q4O3";
            this.Q4O3.Size = new System.Drawing.Size(92, 25);
            this.Q4O3.TabIndex = 26;
            this.Q4O3.TabStop = true;
            this.Q4O3.Text = "Option3";
            this.Q4O3.UseVisualStyleBackColor = true;
            // 
            // Q4O2
            // 
            this.Q4O2.AutoSize = true;
            this.Q4O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q4O2.Location = new System.Drawing.Point(17, 64);
            this.Q4O2.Name = "Q4O2";
            this.Q4O2.Size = new System.Drawing.Size(92, 25);
            this.Q4O2.TabIndex = 25;
            this.Q4O2.TabStop = true;
            this.Q4O2.Text = "Option2";
            this.Q4O2.UseVisualStyleBackColor = true;
            // 
            // Q4O1
            // 
            this.Q4O1.AutoSize = true;
            this.Q4O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q4O1.Location = new System.Drawing.Point(17, 35);
            this.Q4O1.Name = "Q4O1";
            this.Q4O1.Size = new System.Drawing.Size(92, 25);
            this.Q4O1.TabIndex = 24;
            this.Q4O1.TabStop = true;
            this.Q4O1.Text = "Option1";
            this.Q4O1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSlateGray;
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.pictureBox6);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.CNameLbl);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.pictureBox4);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel2.Location = new System.Drawing.Point(1187, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(113, 700);
            this.panel2.TabIndex = 0;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(40, 432);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(49, 40);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 36;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // CNameLbl
            // 
            this.CNameLbl.AutoSize = true;
            this.CNameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.CNameLbl.ForeColor = System.Drawing.Color.White;
            this.CNameLbl.Location = new System.Drawing.Point(17, 73);
            this.CNameLbl.Name = "CNameLbl";
            this.CNameLbl.Size = new System.Drawing.Size(55, 20);
            this.CNameLbl.TabIndex = 36;
            this.CNameLbl.Text = "Name";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(40, 358);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 40);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 35;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(40, 515);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 40);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(40, 282);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 40);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 34;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(35, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(40, 210);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(49, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 33;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Q2O4
            // 
            this.Q2O4.AutoSize = true;
            this.Q2O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q2O4.Location = new System.Drawing.Point(17, 121);
            this.Q2O4.Name = "Q2O4";
            this.Q2O4.Size = new System.Drawing.Size(92, 25);
            this.Q2O4.TabIndex = 27;
            this.Q2O4.TabStop = true;
            this.Q2O4.Text = "Option4";
            this.Q2O4.UseVisualStyleBackColor = true;
            // 
            // Q2
            // 
            this.Q2.Controls.Add(this.Q2O4);
            this.Q2.Controls.Add(this.Q2O3);
            this.Q2.Controls.Add(this.Q2O2);
            this.Q2.Controls.Add(this.Q2O1);
            this.Q2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q2.Location = new System.Drawing.Point(313, 73);
            this.Q2.Name = "Q2";
            this.Q2.Size = new System.Drawing.Size(275, 158);
            this.Q2.TabIndex = 24;
            this.Q2.TabStop = false;
            this.Q2.Text = "Question 1";
            // 
            // Q2O3
            // 
            this.Q2O3.AutoSize = true;
            this.Q2O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q2O3.Location = new System.Drawing.Point(17, 92);
            this.Q2O3.Name = "Q2O3";
            this.Q2O3.Size = new System.Drawing.Size(92, 25);
            this.Q2O3.TabIndex = 26;
            this.Q2O3.TabStop = true;
            this.Q2O3.Text = "Option3";
            this.Q2O3.UseVisualStyleBackColor = true;
            // 
            // Q2O2
            // 
            this.Q2O2.AutoSize = true;
            this.Q2O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q2O2.Location = new System.Drawing.Point(17, 64);
            this.Q2O2.Name = "Q2O2";
            this.Q2O2.Size = new System.Drawing.Size(92, 25);
            this.Q2O2.TabIndex = 25;
            this.Q2O2.TabStop = true;
            this.Q2O2.Text = "Option2";
            this.Q2O2.UseVisualStyleBackColor = true;
            // 
            // Q2O1
            // 
            this.Q2O1.AutoSize = true;
            this.Q2O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q2O1.Location = new System.Drawing.Point(17, 35);
            this.Q2O1.Name = "Q2O1";
            this.Q2O1.Size = new System.Drawing.Size(92, 25);
            this.Q2O1.TabIndex = 24;
            this.Q2O1.TabStop = true;
            this.Q2O1.Text = "Option1";
            this.Q2O1.UseVisualStyleBackColor = true;
            // 
            // Q3O4
            // 
            this.Q3O4.AutoSize = true;
            this.Q3O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q3O4.Location = new System.Drawing.Point(17, 121);
            this.Q3O4.Name = "Q3O4";
            this.Q3O4.Size = new System.Drawing.Size(92, 25);
            this.Q3O4.TabIndex = 27;
            this.Q3O4.TabStop = true;
            this.Q3O4.Text = "Option4";
            this.Q3O4.UseVisualStyleBackColor = true;
            // 
            // Q3O3
            // 
            this.Q3O3.AutoSize = true;
            this.Q3O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q3O3.Location = new System.Drawing.Point(17, 92);
            this.Q3O3.Name = "Q3O3";
            this.Q3O3.Size = new System.Drawing.Size(92, 25);
            this.Q3O3.TabIndex = 26;
            this.Q3O3.TabStop = true;
            this.Q3O3.Text = "Option3";
            this.Q3O3.UseVisualStyleBackColor = true;
            // 
            // Q3O2
            // 
            this.Q3O2.AutoSize = true;
            this.Q3O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q3O2.Location = new System.Drawing.Point(17, 64);
            this.Q3O2.Name = "Q3O2";
            this.Q3O2.Size = new System.Drawing.Size(92, 25);
            this.Q3O2.TabIndex = 25;
            this.Q3O2.TabStop = true;
            this.Q3O2.Text = "Option2";
            this.Q3O2.UseVisualStyleBackColor = true;
            // 
            // Q3O1
            // 
            this.Q3O1.AutoSize = true;
            this.Q3O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q3O1.Location = new System.Drawing.Point(17, 35);
            this.Q3O1.Name = "Q3O1";
            this.Q3O1.Size = new System.Drawing.Size(92, 25);
            this.Q3O1.TabIndex = 24;
            this.Q3O1.TabStop = true;
            this.Q3O1.Text = "Option1";
            this.Q3O1.UseVisualStyleBackColor = true;
            // 
            // Q5O4
            // 
            this.Q5O4.AutoSize = true;
            this.Q5O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q5O4.Location = new System.Drawing.Point(17, 121);
            this.Q5O4.Name = "Q5O4";
            this.Q5O4.Size = new System.Drawing.Size(92, 25);
            this.Q5O4.TabIndex = 27;
            this.Q5O4.TabStop = true;
            this.Q5O4.Text = "Option4";
            this.Q5O4.UseVisualStyleBackColor = true;
            // 
            // Q5O3
            // 
            this.Q5O3.AutoSize = true;
            this.Q5O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q5O3.Location = new System.Drawing.Point(17, 92);
            this.Q5O3.Name = "Q5O3";
            this.Q5O3.Size = new System.Drawing.Size(92, 25);
            this.Q5O3.TabIndex = 26;
            this.Q5O3.TabStop = true;
            this.Q5O3.Text = "Option3";
            this.Q5O3.UseVisualStyleBackColor = true;
            // 
            // Q3
            // 
            this.Q3.Controls.Add(this.Q3O4);
            this.Q3.Controls.Add(this.Q3O3);
            this.Q3.Controls.Add(this.Q3O2);
            this.Q3.Controls.Add(this.Q3O1);
            this.Q3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q3.Location = new System.Drawing.Point(608, 73);
            this.Q3.Name = "Q3";
            this.Q3.Size = new System.Drawing.Size(275, 158);
            this.Q3.TabIndex = 28;
            this.Q3.TabStop = false;
            this.Q3.Text = "Question 1";
            // 
            // Q5O2
            // 
            this.Q5O2.AutoSize = true;
            this.Q5O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q5O2.Location = new System.Drawing.Point(17, 64);
            this.Q5O2.Name = "Q5O2";
            this.Q5O2.Size = new System.Drawing.Size(92, 25);
            this.Q5O2.TabIndex = 25;
            this.Q5O2.TabStop = true;
            this.Q5O2.Text = "Option2";
            this.Q5O2.UseVisualStyleBackColor = true;
            // 
            // Q5
            // 
            this.Q5.Controls.Add(this.Q5O4);
            this.Q5.Controls.Add(this.Q5O3);
            this.Q5.Controls.Add(this.Q5O2);
            this.Q5.Controls.Add(this.Q5O1);
            this.Q5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q5.Location = new System.Drawing.Point(18, 248);
            this.Q5.Name = "Q5";
            this.Q5.Size = new System.Drawing.Size(275, 158);
            this.Q5.TabIndex = 28;
            this.Q5.TabStop = false;
            this.Q5.Text = "Question 1";
            // 
            // Q5O1
            // 
            this.Q5O1.AutoSize = true;
            this.Q5O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q5O1.Location = new System.Drawing.Point(17, 35);
            this.Q5O1.Name = "Q5O1";
            this.Q5O1.Size = new System.Drawing.Size(92, 25);
            this.Q5O1.TabIndex = 24;
            this.Q5O1.TabStop = true;
            this.Q5O1.Text = "Option1";
            this.Q5O1.UseVisualStyleBackColor = true;
            // 
            // Q6O4
            // 
            this.Q6O4.AutoSize = true;
            this.Q6O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q6O4.Location = new System.Drawing.Point(17, 121);
            this.Q6O4.Name = "Q6O4";
            this.Q6O4.Size = new System.Drawing.Size(92, 25);
            this.Q6O4.TabIndex = 27;
            this.Q6O4.TabStop = true;
            this.Q6O4.Text = "Option4";
            this.Q6O4.UseVisualStyleBackColor = true;
            // 
            // Q6O3
            // 
            this.Q6O3.AutoSize = true;
            this.Q6O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q6O3.Location = new System.Drawing.Point(17, 92);
            this.Q6O3.Name = "Q6O3";
            this.Q6O3.Size = new System.Drawing.Size(92, 25);
            this.Q6O3.TabIndex = 26;
            this.Q6O3.TabStop = true;
            this.Q6O3.Text = "Option3";
            this.Q6O3.UseVisualStyleBackColor = true;
            // 
            // Q6O2
            // 
            this.Q6O2.AutoSize = true;
            this.Q6O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q6O2.Location = new System.Drawing.Point(17, 64);
            this.Q6O2.Name = "Q6O2";
            this.Q6O2.Size = new System.Drawing.Size(92, 25);
            this.Q6O2.TabIndex = 25;
            this.Q6O2.TabStop = true;
            this.Q6O2.Text = "Option2";
            this.Q6O2.UseVisualStyleBackColor = true;
            // 
            // Q6O1
            // 
            this.Q6O1.AutoSize = true;
            this.Q6O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q6O1.Location = new System.Drawing.Point(17, 35);
            this.Q6O1.Name = "Q6O1";
            this.Q6O1.Size = new System.Drawing.Size(92, 25);
            this.Q6O1.TabIndex = 24;
            this.Q6O1.TabStop = true;
            this.Q6O1.Text = "Option1";
            this.Q6O1.UseVisualStyleBackColor = true;
            // 
            // Q6
            // 
            this.Q6.Controls.Add(this.Q6O4);
            this.Q6.Controls.Add(this.Q6O3);
            this.Q6.Controls.Add(this.Q6O2);
            this.Q6.Controls.Add(this.Q6O1);
            this.Q6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q6.Location = new System.Drawing.Point(313, 248);
            this.Q6.Name = "Q6";
            this.Q6.Size = new System.Drawing.Size(275, 158);
            this.Q6.TabIndex = 28;
            this.Q6.TabStop = false;
            this.Q6.Text = "Question 1";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DodgerBlue;
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.logoutPop);
            this.panel1.Controls.Add(this.QTime);
            this.panel1.Controls.Add(this.DateP);
            this.panel1.Controls.Add(this.TimeLbl);
            this.panel1.Controls.Add(this.TimeBar);
            this.panel1.Controls.Add(this.Q10);
            this.panel1.Controls.Add(this.Q9);
            this.panel1.Controls.Add(this.Q8);
            this.panel1.Controls.Add(this.Q4);
            this.panel1.Controls.Add(this.SubLbl);
            this.panel1.Controls.Add(this.Q7);
            this.panel1.Controls.Add(this.Q6);
            this.panel1.Controls.Add(this.Q5);
            this.panel1.Controls.Add(this.Q3);
            this.panel1.Controls.Add(this.Q2);
            this.panel1.Controls.Add(this.Q1);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.SubmitBtn);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1300, 700);
            this.panel1.TabIndex = 33;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Q1
            // 
            this.Q1.Controls.Add(this.Q1O4);
            this.Q1.Controls.Add(this.Q1O3);
            this.Q1.Controls.Add(this.Q1O2);
            this.Q1.Controls.Add(this.Q1O1);
            this.Q1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Q1.Location = new System.Drawing.Point(18, 73);
            this.Q1.Name = "Q1";
            this.Q1.Size = new System.Drawing.Size(275, 158);
            this.Q1.TabIndex = 23;
            this.Q1.TabStop = false;
            this.Q1.Text = "Question 1";
            // 
            // Q1O4
            // 
            this.Q1O4.AutoSize = true;
            this.Q1O4.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q1O4.Location = new System.Drawing.Point(17, 121);
            this.Q1O4.Name = "Q1O4";
            this.Q1O4.Size = new System.Drawing.Size(92, 25);
            this.Q1O4.TabIndex = 27;
            this.Q1O4.TabStop = true;
            this.Q1O4.Text = "Option4";
            this.Q1O4.UseVisualStyleBackColor = true;
            // 
            // Q1O3
            // 
            this.Q1O3.AutoSize = true;
            this.Q1O3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q1O3.Location = new System.Drawing.Point(17, 92);
            this.Q1O3.Name = "Q1O3";
            this.Q1O3.Size = new System.Drawing.Size(92, 25);
            this.Q1O3.TabIndex = 26;
            this.Q1O3.TabStop = true;
            this.Q1O3.Text = "Option3";
            this.Q1O3.UseVisualStyleBackColor = true;
            // 
            // Q1O2
            // 
            this.Q1O2.AutoSize = true;
            this.Q1O2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q1O2.Location = new System.Drawing.Point(17, 64);
            this.Q1O2.Name = "Q1O2";
            this.Q1O2.Size = new System.Drawing.Size(92, 25);
            this.Q1O2.TabIndex = 25;
            this.Q1O2.TabStop = true;
            this.Q1O2.Text = "Option2";
            this.Q1O2.UseVisualStyleBackColor = true;
            // 
            // Q1O1
            // 
            this.Q1O1.AutoSize = true;
            this.Q1O1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Q1O1.Location = new System.Drawing.Point(17, 35);
            this.Q1O1.Name = "Q1O1";
            this.Q1O1.Size = new System.Drawing.Size(92, 25);
            this.Q1O1.TabIndex = 24;
            this.Q1O1.TabStop = true;
            this.Q1O1.Text = "Option1";
            this.Q1O1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(817, 38);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(72, 10);
            this.button4.TabIndex = 22;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // SubmitBtn
            // 
            this.SubmitBtn.BackColor = System.Drawing.Color.Lime;
            this.SubmitBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.SubmitBtn.ForeColor = System.Drawing.Color.Navy;
            this.SubmitBtn.Location = new System.Drawing.Point(521, 642);
            this.SubmitBtn.Name = "SubmitBtn";
            this.SubmitBtn.Size = new System.Drawing.Size(134, 30);
            this.SubmitBtn.TabIndex = 18;
            this.SubmitBtn.Text = "Submit";
            this.SubmitBtn.UseVisualStyleBackColor = false;
            this.SubmitBtn.Click += new System.EventHandler(this.SubmitBtn_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(817, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 29);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quiz";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Old English Text MT", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "Quiz";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(247, 65);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 1;
            this.button3.Text = "No";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // exitPop
            // 
            this.exitPop.BackColor = System.Drawing.Color.Silver;
            this.exitPop.Controls.Add(this.label13);
            this.exitPop.Controls.Add(this.button3);
            this.exitPop.Controls.Add(this.button5);
            this.exitPop.Location = new System.Drawing.Point(423, 162);
            this.exitPop.Name = "exitPop";
            this.exitPop.Size = new System.Drawing.Size(455, 100);
            this.exitPop.TabIndex = 34;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label13.Location = new System.Drawing.Point(5, 13);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(431, 25);
            this.label13.TabIndex = 2;
            this.label13.Text = "Are You Sure You want to close the Programm?";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(155, 65);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 0;
            this.button5.Text = "Yes";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 556);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 15);
            this.label14.TabIndex = 39;
            this.label14.Text = "Logout";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Location = new System.Drawing.Point(36, 477);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(60, 15);
            this.label15.TabIndex = 38;
            this.label15.Text = "Trial Exam";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(42, 399);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 15);
            this.label16.TabIndex = 37;
            this.label16.Text = "Results";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(38, 327);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 15);
            this.label17.TabIndex = 36;
            this.label17.Text = "Lecturer";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(35, 253);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(60, 15);
            this.label18.TabIndex = 35;
            this.label18.Text = "Questions";
            // 
            // Testing2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1300, 700);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.exitPop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Testing2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Testing2";
            this.logoutPop.ResumeLayout(false);
            this.logoutPop.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.Q10.ResumeLayout(false);
            this.Q10.PerformLayout();
            this.Q9.ResumeLayout(false);
            this.Q9.PerformLayout();
            this.Q8.ResumeLayout(false);
            this.Q8.PerformLayout();
            this.Q7.ResumeLayout(false);
            this.Q7.PerformLayout();
            this.Q4.ResumeLayout(false);
            this.Q4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.Q2.ResumeLayout(false);
            this.Q2.PerformLayout();
            this.Q3.ResumeLayout(false);
            this.Q3.PerformLayout();
            this.Q5.ResumeLayout(false);
            this.Q5.PerformLayout();
            this.Q6.ResumeLayout(false);
            this.Q6.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.Q1.ResumeLayout(false);
            this.Q1.PerformLayout();
            this.exitPop.ResumeLayout(false);
            this.exitPop.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private ProgressBar TimeBar;
        private RadioButton Q10O4;
        private Panel logoutPop;
        private Label label2;
        private Button button1;
        private Button button2;
        private DateTimePicker QTime;
        private DateTimePicker DateP;
        private Label TimeLbl;
        private GroupBox Q10;
        private RadioButton Q10O3;
        private RadioButton Q10O2;
        private RadioButton Q10O1;
        private GroupBox Q9;
        private RadioButton Q9O4;
        private RadioButton Q9O3;
        private RadioButton Q9O2;
        private RadioButton Q9O1;
        private GroupBox Q8;
        private RadioButton Q8O4;
        private RadioButton Q8O3;
        private RadioButton Q8O2;
        private RadioButton Q8O1;
        private Label SubLbl;
        private GroupBox Q7;
        private RadioButton Q7O4;
        private RadioButton Q7O3;
        private RadioButton Q7O2;
        private RadioButton Q7O1;
        private GroupBox Q4;
        private RadioButton Q4O4;
        private RadioButton Q4O3;
        private RadioButton Q4O2;
        private RadioButton Q4O1;
        private Panel panel2;
        private PictureBox pictureBox6;
        private Label CNameLbl;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private RadioButton Q2O4;
        private GroupBox Q2;
        private RadioButton Q2O3;
        private RadioButton Q2O2;
        private RadioButton Q2O1;
        private RadioButton Q3O4;
        private RadioButton Q3O3;
        private RadioButton Q3O2;
        private RadioButton Q3O1;
        private RadioButton Q5O4;
        private RadioButton Q5O3;
        private GroupBox Q3;
        private RadioButton Q5O2;
        private GroupBox Q5;
        private RadioButton Q5O1;
        private RadioButton Q6O4;
        private RadioButton Q6O3;
        private RadioButton Q6O2;
        private RadioButton Q6O1;
        private GroupBox Q6;
        private Panel panel1;
        private GroupBox Q1;
        private RadioButton Q1O4;
        private RadioButton Q1O3;
        private RadioButton Q1O2;
        private RadioButton Q1O1;
        private Button button4;
        private Button SubmitBtn;
        private Label label4;
        private Label label1;
        private System.Windows.Forms.Timer timer1;
        private Button button3;
        private Panel exitPop;
        private Label label13;
        private Button button5;
        private Panel panel3;
        private Label label3;
        private Button button6;
        private Button button7;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
        private Label label18;
    }
}